use Astro::Sunrise;
use LWP::UserAgent;
use DateTime;

sub getTimeZoneByLatLong {
	my ($lat, $long) = @_;
	$url = "http://api.geonames.org/timezone?lat=$lat&lng=$long&username=demo";

	$tz = 'America/Los_Angeles';

	# FIXME: Temporarily just hardcoding to make it faster
	return $tz;

	my $ua = new LWP::UserAgent;
	$ua->timeout(2);
	my $request = new HTTP::Request('GET', $url);
	my $response = $ua->request($request);
	my $content = $response->content();

	if($content =~ /<timezoneId>(.+)<\/timezoneId>/m) { $tz = $1; }

	return $tz;
}

sub addTimeString {
	my ($dt, $timestr) = @_;
	my ($h, $m)  = split(/:/, $timestr);
	my $tmp = $dt->clone();
	$tmp->set_hour($h);
	$tmp->set_minute(0);
	$tmp->set_second(0);
	return $tmp;
}
	
sub getSunriseSunset {
	($dt, $lat, $long) = @_;
	($sunrise, $sunset) = sunrise($dt->year, $dt->month, $dt->day, $long, $lat, $dt->offset()/3600.0, 0); 
	#($sunrise, $sunset) = sunrise($dt->year, $dt->month, $dt->day, $long, $lat, $dt->offset()/3600.0, $dt->is_dst());
	#($sunrise, $sunset) = sunrise($dt->year, $dt->month, $dt->day, $long, $lat, 0, 0); 
	$dt1 = addTimeString($dt, $sunrise);
	$dt2 = addTimeString($dt, $sunset);
	return ($dt1, $dt2);
}


{
	$datetime = $ARGV[0];
	$lat = $ARGV[1];
	$long = $ARGV[2];

	$tz = getTimeZoneByLatLong($lat, $long);

	#($month, $day, $year) = split(/\//, $datetime);
	#$dt = DateTime->new( year=>$year, month=>$month, day=>$day, time_zone=>$tz );

	$dt = DateTime->from_epoch( epoch=>$datetime, time_zone=>$tz );
	#$dt = DateTime->from_epoch( epoch=>$datetime );

	#for($i=0; $i<20; $i++) {
	#	($rise1, $set1) = getSunriseSunset($dt, $lat, $long);
	#	$sunrise = $rise1->strftime("%F %H:%M");
	#	$sunset = $set1->strftime("%F %H:%M");
	#	print "sunrise=\"$sunrise\" sunset=\"$sunset\"\n";
	#	$dt->add( days=>1 );
	#}

	($rise1, $set1) = getSunriseSunset($dt, $lat, $long);
	$dt->add( days=>1 );
	($rise2, $set2) = getSunriseSunset($dt, $lat, $long);

	$day = $rise2->strftime("%F");
	$sunrise = $rise2->epoch();
	$sunset = $set1->epoch();
	print "date=$day sunrise=$sunrise sunset=$sunset\n";
	#$sunrise = $rise2->strftime("%F %H:%M");
	#$sunset = $set1->strftime("%F %H:%M");
	#print "date=$day sunrise=$sunrise sunset=$sunset\n";
}
