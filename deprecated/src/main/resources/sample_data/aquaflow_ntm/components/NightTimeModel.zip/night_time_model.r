####### Script to Calculate averages for the Hydrolab data
# Date: Mar'2011
# Author: SV and FS
# Input: Water quality data (at least temperature and dissolved oxygen): Hydrolab_Stationary.txt
# Output: Hourly averages
# Comment: For One-hour estimates
######################################

current_input_fn = ""
previous_input_fn = ""
sunrise = ""
sunset = ""
output_fn = ""
do_fn = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
    #cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if current_input_fn, previous_input_fn and output_fn are specified
if (current_input_fn == "" || previous_input_fn == "" || output_fn == "" || sunrise == "" || sunset == "" || do_fn == ""){
   cat("error: must specify sunrise, sunset, do, current input, previous input, and output files\n")
   quit()
}

# Check if current_input_fn exists
if (file.exists(current_input_fn) == FALSE){
   cat("error: cannot access current input file\n")
   quit()
}

# Check if previous_input_fn exists
if (file.exists(previous_input_fn) == FALSE){
   cat("error: cannot access previous input file\n")
   quit()
}

# Reading the water quality data file 

  # Reading Current's Day Hourly Averaged Data
  CurrentTable = read.table(file=current_input_fn, header=TRUE, sep="\t")

  # Reading Previous' Day Hourly Averaged Data
  PreviousTable = read.table(file=previous_input_fn, header=TRUE, sep="\t")

  # Put the two tables together
  CalcTable = rbind(PreviousTable, CurrentTable)

  #MeanTable = read.table(file=input_fn, header=TRUE, sep="\t")
  #CalcTable = MeanTable

  # For CalcTable, calculate Cs, (Cs-C), and dC/dt

  # Calculating Saturated DO concentration
  CalcTable$TempK = CalcTable$Temp + 273.15
  CalcTable$Cs=exp(-139.34411+(157570.1/CalcTable$TempK)-(66423080/(CalcTable$TempK)^2)+
                  (12438000000/(CalcTable$TempK)^3)-(862194900000/(CalcTable$TempK)^4))
  # Calculating DO d�ficit or surplus
  CalcTable$Cs_C = CalcTable$Cs - CalcTable$DO
  
  # Calculating dC/dt
  for (i in 1:(length(CalcTable$Temp)-1)){ 
     CalcTable$dCdt[[1]] = 0
     CalcTable$dCdt[i+1] = CalcTable$DO[[i+1]] - CalcTable$DO[[i]]
  }
  
  # To check adequate conversion between DTseconds and Timestamp
  #NewDates = as.POSIXct(CalcTable$DTseconds, origin="1970-01-01", tz="PST8PDT")

  # Writing the table of the hourly averages for the available data, including DO
  write.table(CalcTable, file = do_fn, append = FALSE, quote = FALSE, sep = "\t",
            na = "NA", dec = ".", row.names = FALSE, col.names = TRUE )

# CALCULATING THE REAERATION COEFFICIENT

  #AA = as.character(NewDates)

  #ids.sunset<- grep(sunset, AA, ignore.case = FALSE, value = FALSE,
  #             fixed = TRUE, useBytes = FALSE)
  #ids.sunrise<- grep(sunrise, AA, ignore.case = FALSE, value = FALSE,
  #             fixed = TRUE, useBytes = FALSE)

  #ids<- c(ids.sunset:ids.sunrise) 
 
  # Extracting the data for the night of analysis
  Night = subset(subset(CalcTable, DTseconds > sunset), DTseconds <= sunrise )
  #Night<- data.frame(CalcTable[ids, ]) 

  # Figuring out the day
  #my_day = substr(as.character(NewDates[ids[length(ids)]]),1,10)

  #  plot(Night$Cs_C, Night$dCdt, xlim=c(-0.25,3.0), ylim=c(-0.25, 0.1),
  #      xlab="(Cs-C)", ylab="dC/dt", col = 3, type="p")

  # Only data for which undersaturated conditions exist (Cs_C is greater than 0) 
  Night = subset(Night, Night$Cs_C > 0)

  #Modify x and y ranges (xlim and ylim) so all the points can be viewed
  #Modify date on the title (main) so it matches the data being used 
  #  plot(Night$Cs_C, Night$dCdt, xlim=c(0,2.5), ylim=c(-0.25, 0.1),
  #  xlab="(Cs-C)", ylab="dC/dt", type="p",pch=15, col = "red", 
  #  cex.axis=1.2, cex.lab=1.2, cex.main=1.2,
  #  main="K2 and CR from Night Time Method - October 23-24/2009")

  # TEMPERATURE INFO
  #  print("TEMPERATURE DATA")
  max.Temp = max(Night$Temp)
  min.Temp = min(Night$Temp)
  range.Temp = max.Temp - min.Temp
  mean.Temp = mean(Night$Temp)

  # DO INFO  
  #  print("DO DATA")
  max.DO = max(Night$DO)
  min.DO = min(Night$DO)
  range.DO = max.DO - min.DO
  mean.DO = mean(Night$DO)

  # Linear model to obtain slope and intercept of the data
  # See final plot for results of K2 and CR
  lm_Night = lm(Night$dCdt ~ Night$Cs_C)
  CR.K2 = format(lm_Night$coefficients, digits=3)
  R2 = format(summary(lm_Night)$adj.r.squared, digits=2)
  #  text(0.7,-0.05, paste("Intercept(CR)=",CR.K2[1],"mg O2 L-1 h-1"), cex=1.2)
  #  text(0.7,-0.07, paste("Slope(K2)=",CR.K2[2],"h-1"), cex=1.2)
  #  text(0.7,-0.09, paste("R2=",R2), cex=1.2)
  #  abline(lm_Night)
  #  summary(lm_Night)

  # Write output
  write("Date\ttemp\tcr.ntm\tk2.ntm", file=output_fn)
  write(paste(date, "\t", mean.Temp, "\t", CR.K2[1], "\t", CR.K2[2], sep=""), file=output_fn, append=TRUE)
      
