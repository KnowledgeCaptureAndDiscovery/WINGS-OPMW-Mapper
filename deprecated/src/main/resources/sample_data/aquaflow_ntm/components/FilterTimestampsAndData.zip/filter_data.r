####### Script to clean Hydrolab data
# Date: March'2011
# Author: SV and FS
# Input: Hydrolab data
# Output: Cleaned data, with timestamps
# Comment: Also removes N/As from DO
######################################

input_fn = ""
output_fn = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
#    cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if input_fn and output_fn are specified
if (input_fn == "" || output_fn == ""){
   cat("error: must specify input and output files\n")
   quit()
}

# Check if input_fn exists
if (file.exists(input_fn) == FALSE){
   cat("error: cannot access input file\n")
   quit()
}

# Reading the water quality data file 
  A<- read.table(file=input_fn, header=TRUE, fill=TRUE, sep="\t")
  #MainTable<- subset(A, A$DO != "N/A") # removes rows with N/A's
  MainTable<- subset(A, A$DO != "NA") # removes rows with NA's
  
  MainTable$DateAndTime<- strptime(MainTable$DateTime, "%m/%d/%Y %I:%M:%S %p", tz="PST8PDT")
  Date_Time<- strptime(MainTable$DateTime, "%m/%d/%Y %I:%M:%S %p", tz="PST8PDT")
  MainTable$DTseconds<-  as.numeric(unclass(as.POSIXct(Date_Time)))

  # Writing a table to output file
  write.table(MainTable, file = output_fn, append = FALSE, quote = FALSE, sep = "\t",
              na = "NA", dec = ".", row.names = FALSE, col.names = TRUE )
