use Data::Dumper;
use GD::Graph::linespoints;

sub round {
	$data = shift;
	$precision = shift;
	return sprintf("%${precision}f", $data);
}

sub plotGraph {
	my ($yvals, $dates, $yaxis, $title, $fname) = @_;
	$data = [ $dates, $yvals ];
	$min = 999999;
	$max = -999999;
	foreach $v(@$yvals) {
		$min = $v if($v < $min);
		$max = $v if($v > $max);
	}
	$min = $min - ($max - $min)/10;
	$max = $max + ($max - $min)/10;
	
	$my_graph = new GD::Graph::linespoints(800,600);
	$my_graph->set(
		x_label => 'Date',
		y_label => $yaxis,
		y_max_value => $max,
		y_min_value => $min,
		#y_label_skip => 2,
		x_labels_vertical => 1,
		box_axis => 1,
		y_tick_number => 20,
	);
	my $gd = $my_graph->plot($data) or die $my_graph->error;
	open(IMG, ">$fname") or die $!;
	binmode IMG;
	print IMG $gd->gif;
	close IMG;
}

@ins = ();
@outs = ();
$outfl = 0;
foreach $file(@ARGV) {
	if($file eq "-") { $outfl = 1; }
	elsif($outfl) { push(@outs, $file); }
	else { push(@ins, $file); }
}

@CorrDO = ();
@CR24 = ();
@Photo = ();
@GPP = ();
@NDM = ();
@PR = ();
@dates = ();

foreach $file(@ins) {
	open(FL, "<$file");
	@headers = split(/\s+/, <FL>);
	@data = split(/\s+/, <FL>);
	%hash = ();
	close(FL);
	for(my $i=0; $i<scalar(@headers); $i++) {
		$hash{$headers[$i]} = $data[$i];
	}

	push(@CorrDO, round($hash{'sum.corrDO.day'}, 4));
	push(@CR24, round($hash{'CR24'}, 4));
	push(@Photo, round($hash{'photo.rest'}, 4));
	push(@GPP, round($hash{'GPP'}, 4));
	push(@NDM, round($hash{'NDM'}, 4));
	push(@PR, round($hash{'P.R'}, 5));

	push(@dates, $hash{'Date'});
}

#print Dumper \@CorrDO;
#print Dumper \@CR24;

plotGraph(\@CorrDO, \@dates, "sum.corrDO.day", "sum.corrDO.day", $outs[0]);
plotGraph(\@CR24, \@dates, "CR24", "CR24", $outs[1]);
plotGraph(\@Photo, \@dates, "photo.rest", "photo.rest", $outs[2]);
plotGraph(\@GPP, \@dates, "GPP", "GPP", $outs[3]);
plotGraph(\@NDM, \@dates, "NDM", "NDM", $outs[4]);
plotGraph(\@PR, \@dates, "P.R", "P.R", $outs[5]);

#print "---------------------- DO ----------------------------\n";
#print Dumper %CorrDO;
#print "---------------------- CR ----------------------------\n";
#print Dumper %CR24;
#print "---------------------- Photo ----------------------------\n";
#print Dumper %Photo;
#print "---------------------- GPP ----------------------------\n";
#print Dumper %GPP;
#print "---------------------- NDM ----------------------------\n";
#print Dumper %NDM;
#print "---------------------- PR ----------------------------\n";
#print Dumper %PR;

