####### Script to obtain metabolism estimates ######
# Date: May 02/2010
# Author: SV
# Input: input_fn = OutputHourlyAveragedData
#        parameters.txt
# Output: Metabolism Estimates - K2 from empirical methods
# Comment: Correction for effect of temperature variations on K2 and CR are developed
#          Respiration rates are calculated from an average of the night data
######################################

input_fn = ""
output_fn = ""
parameters_fn = ""
sunrise = ""
sunset = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
#    cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if input_fn and output_fn are specified
if (input_fn == "" || output_fn == "" || parameters_fn == "" || sunrise == "" || sunset == ""){
   cat("error: must specify sunrise, sunset, parameters, do, input, and output files\n")
   quit()
}

# Check if input_fn exists
if (file.exists(input_fn) == FALSE){
   cat("error: cannot access input file\n")
   quit()
}

# Check if parameters_fn exists
if (file.exists(parameters_fn) == FALSE){
   cat("error: cannot access the parameters file\n")
   quit()
}

  # Reading the Hourly Averaged Data
  CalcTable = read.table(file=input_fn, header=TRUE, sep="\t")

  # Reading the parameters table
  parameters = read.table(file=parameters_fn, header=TRUE, sep="")
  
  # CORRECTING FOR REAERATION

  # Creating a list "param" containing the required/initial parameters
  # Required parameters for the calculation of the Reaeration corrected rate of change per area (g/ m2 min)
  param = list()
  param$day = as.character(parameters$Date)      # date of analysis
  param$K2 = parameters$K2_edm       # Reaerat coeff in h-1 (Obtained from the night time method)
  param$MeanDepth = parameters$depth # mean depth in meters  
  # These two are not used here
  #  param$Velocity = parameters$vel    # velocity in m/s
  #  param$slope = parameters$slope     # bed slope in m/m
  # value of the barometric pressure, potentially coming from the weather station
  # Important if elevation is greater than 1000 m above sea level (default 760 mmHg)
  param$BarPres = parameters$BarPres 

  # Calculate time
  my_last_time = paste(param$day, "23:59:59")
  my_last_ts = as.numeric(unclass(as.POSIXct(strptime(my_last_time, "%Y-%m-%d %H:%M:%S", tz="PST8PDT"))))
  my_first_ts = my_last_ts - 86400 - 3599 # back to the previous day, at 23:00

  # Subset data to only previous day@23hrs until the end of the current day
  SecondTable = subset(subset(CalcTable, DTseconds >= my_first_ts), DTseconds <= my_last_ts)

  # Convert sunrise, sunset
  sunrise = as.numeric(sunrise)
  sunset = as.numeric(sunset)

  # Calculating the dissolved Oxygen saturation concentration for a given temperature and pressure
  # Reading DOsat at pressure 755 or 760 mmHg
  # LnCs = -139.34411 + (1.575701 x 10^5 / T) - (6.642308 x 10^7 / T^2) + (1.243800 x 10^10 / T^3)
  # - (8.621949 x 10^11 / T^4)    (APHA, 1992)   ==Temperature in Kelvin = C + 273.15
  
  for (i in 1:length(SecondTable$Temp)){
    SecondTable$DOsat[i]<- exp(-139.34411 + (157570.1/(SecondTable$Temp[i]+273.15)) -
    (66423080/(SecondTable$Temp[i]+273.15)^2)+ (12438000000/(SecondTable$Temp[i]+273.15)^3) -
    (862194900000/(SecondTable$Temp[i]+273.15)^4))
  }

  # Correcting DOsat for cases when elevation is greater than 1000 m above sea level
  SecondTable$DOsat_corr<- SecondTable$DOsat * (param$BarPres / 760)
        
  # Calculating the DO deficit or surplus (mg/L)
  # If the number is positive, there is surplus of DO. If negative, there is deficit of DO in the water.
  # Please, leave (C-Cs) here. -Convenient for convention
  SecondTable$DefSur<- SecondTable$DO - SecondTable$DOsat_corr

  # Correcting for reaeration
  for (i in 1:length (SecondTable$DO)){    
    # Assigning K2 temp corrected for the respective iteration (h-1)  
    SecondTable$K_adjusted[i] = (param$K2)*1.024^((SecondTable$Temp[i])- 20)
    # Calculating the gas-exchange per unit volume(gr m-3 h-1)
    SecondTable$exchange[i] = SecondTable$DefSur[i] * SecondTable$K_adjusted[i]
  }

  # SAME AS metabolism.....
  # Creating a new list "ThirdTable" storing the necessary values from "SecondTable"
  ThirdTable = list()
  for (i in 1 : (length(SecondTable$DO) - 1)){
    # Leave here the same interval (only removing the step for the hour of the previous day
    ThirdTable$DTseconds[i] = SecondTable$DTseconds[i+1]     
    bb = c(SecondTable$DO[i], SecondTable$DO[i+1])
      ThirdTable$AvgDO[i] = mean(bb)
    cc = c(SecondTable$Temp[i], SecondTable$Temp[i+1])
      ThirdTable$AvgTemp[i] = mean(cc)    
    dd = c(SecondTable$exchange[i], SecondTable$exchange[i+1])
       ThirdTable$AvgExchange[i] = mean(dd)  #(gr / m3 h) 
    # DO rate of change (mg/L = g/m3)
    ThirdTable$DOrateChangeVol[i] = (SecondTable$DO[i+1] - SecondTable$DO[i]) # (g / m3 h)
    # reaeration corrected rate of change per volume
    ThirdTable$ReaerCorrRateChangeVol[i] = ThirdTable$AvgExchange[i] + ThirdTable$DOrateChangeVol[i] # (gr / m3 h)
    # finally       
    ThirdTable$ReaerCorrRateChangeArea[i] = ThirdTable$ReaerCorrRateChangeVol[i] * param$MeanDepth # (gr / m2 h)     
  }

  # TO CALCULATE PRIMARY PRODUCTIVITY AND COMMUNITY RESPIRATION

  # Obtaining the indices of daylight hours for the day of analysis
  daylight = which(ThirdTable$DTseconds >= sunrise & ThirdTable$DTseconds <= sunset)
  
  ids.sunrise = min(daylight)
  ids.sunset = max(daylight) 
  
  # subset of the day-time reaeration-corrected rate of change
  ThirdTable$ReaerationCorrRateChange_day[1 : (length(daylight))]<- ThirdTable$ReaerCorrRateChangeArea[ids.sunrise : ids.sunset]

  # This portion deals with the respiration using the average of the night time rates.
  # Subset of the night-time reaeration-corrected rate of change
  NightTimeBefore = which(ThirdTable$DTseconds < sunrise)
  NightTimeAfter = which(ThirdTable$DTseconds > sunset)
  NightTime = c(NightTimeBefore, NightTimeAfter)
       
  # Calculating community respiration
  ThirdTable$ReaerationCorrRateChange_night[1 : (length(NightTime))] = ThirdTable$ReaerCorrRateChangeArea[NightTime]

  CR = mean(ThirdTable$ReaerationCorrRateChange_night)
  # Calculating the average temperature for night rates
  NightTemp = mean(ThirdTable$AvgTemp[NightTime])
  # Correcting CR for daily temperature variations    
  CRcorr = array()
  CRcorr = (CR*1.07^(ThirdTable$AvgTemp - NightTemp)) # ***** NEW CHANGE: changed 20 for NightTemp
  ThirdTable$CR_adjusted = CRcorr
  
  # For the metabolism calculation only Time stamp and reaeration corrected rate of change are necessary    
  # THE RESULTS I AM LOOKING FOR:

  # sum of the photoperiod rates of DO change (gr /m2 Ts)    
  ThirdTable$sum.corrDO.day = sum(ThirdTable$ReaerationCorrRateChange_day)    
  # cat("The sum of the photoperiod rates of DO change is:", ThirdTable$sum.corrDO.day, "(gr / m-2 h-1)")

  # Respiration Data
  # *****CHANGE: notice now data is coming from ThirdTable
  # The total CR24 is the sum of the rates throughout the day for the temp corrected values of R
  ThirdTable$CR24 = sum(ThirdTable$CR_adjusted)
  # cat("The CR24 rate is:", ThirdTable$CR24, "(gr / m2 day)")
  
  # Calculation of the photoperiod respiration rate 
  ee = c()
  ee = ThirdTable$CR_adjusted[ids.sunrise:ids.sunset]
  ThirdTable$photo.resp = sum(ee)
  # cat("The total respiration rate during photoperiod hours is:", ThirdTable$photo.resp, "(gr / m2-day)")  
     
  # Calculation of Gross Primary Productivity in g / m2-day
  ThirdTable$GPP = sum(ThirdTable$sum.corrDO.day + abs(ThirdTable$photo.resp))
  # cat("The Gross Primary Productivity for the selected day is:", ThirdTable$GPP, "(gr / m2-day)")

  # Calculation of Net Daily Metabolism in g / m2-day
  ThirdTable$NDM<- ThirdTable$GPP + ThirdTable$CR24
  # cat("The Net Daily Metabolism for the selected day is:", ThirdTable$NDM, "(gr / m2-day)")
    
  # Calculation of the P/R ratio
  ThirdTable$P.R = ThirdTable$GPP / abs(ThirdTable$CR24) 
  # cat("The P/R ratio is:", ThirdTable$P.R)

# Storing Results in a data frame
  Results = list()
  Results$sum.corrDO.day = ThirdTable$sum.corrDO.day
  Results$CR24 = ThirdTable$CR24
  Results$photo.resp = ThirdTable$photo.resp
  Results$GPP = ThirdTable$GPP
  Results$NDM = ThirdTable$NDM
  Results$P.R = ThirdTable$P.R

  # Write metabolism model output
  write("Date\tsum.corrDO.day\tCR24\tphoto.rest\tGPP\tNDM\tP.R", file=output_fn)
  write(paste(param$day, "\t", Results$sum.corrDO.day, "\t", Results$CR24, "\t", Results$photo.resp, "\t", Results$GPP, "\t", Results$NDM, "\t", Results$P.R, sep=""), file=output_fn, append=TRUE)
