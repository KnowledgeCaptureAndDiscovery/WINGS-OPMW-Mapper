#!/usr/bin/perl

use File::Copy;

$ntmfile = $ARGV[0];
$otherfile = $ARGV[1];
$outfile = $ARGV[2];
$algofile = $ARGV[3];

open(FL, "<$ntmfile");
@data = <FL>;
$data = join(@data, '');
chomp($data);
close(FL);

if(!$data)  {
	copy($ntmfile, $outfile);
	$algo = "NTM";
}
else {
	copy($otherfile, $outfile);
	$algo = "Empirical";
}

open(FL2, ">$algofile");
print FL2 "$algo\n";
close(FL2);

