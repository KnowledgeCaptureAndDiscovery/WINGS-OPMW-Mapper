####### Script to obtain metabolism estimates
# Date: Mar'2011
# Author: SV and FS
# Input: Hydrolab_Stationary.txt
# Output: Metabolism Estimates K2 and CR from Nighttime method
# Comment: Correction for effect of temperature variations on K2 and CR are developed
#          Respiration rates are taken from the night-time method)
#          New-- Includes data for the last hour of the previous day
######################################

input_fn = ""
output_fn = ""
depth_fn = ""
do_fn = ""
sunrise = ""
sunset = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
#    cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if input_fn and output_fn are specified
if (input_fn == "" || output_fn == "" || depth_fn == "" || do_fn == "" || sunrise == "" || sunset == ""){
   cat("error: must specify sunrise, sunset, depth, do, input, and output files\n")
   quit()
}

# Check if input_fn exists
if (file.exists(input_fn) == FALSE){
   cat("error: cannot access input file\n")
   quit()
}

# Check if depth_fn exists
if (file.exists(depth_fn) == FALSE){
   cat("error: cannot access depth file\n")
   quit()
}

# Check if do_fn exists
if (file.exists(do_fn) == FALSE){
   cat("error: cannot access do file\n")
   quit()
}

  # Reading the night-time-model file
  NTM = read.table(file=input_fn, header=TRUE, sep="\t")

  # Extract info from NTM
  param = list()
  param$day = as.character(NTM$Date)	# date of analysis
  param$MNTTemp = NTM$temp		# Mean NightTime Temperature (C) at which K2 was calculated  
  param$CR.NTM = NTM$cr.ntm		# Community Respiration in mg L-1 h-1 obtained from the night time
  param$K2 = NTM$k2.ntm			# Reaerat coeff in h-1 (Obtained from the night time method)

  # Read the DO file
  DO = read.table(file=do_fn, header=TRUE, sep="\t")
  CalcTable = DO

  # Correct K2 and CR.NTM for the mean night temperature
  for (i in 1:length(CalcTable$Temp)){
    CalcTable$K_adjusted[i] = (param$K2)*1.024^(CalcTable$Temp[i] - param$MNTTemp)
    CalcTable$CR_adjusted[i] = (param$CR.NTM)*1.07^(CalcTable$Temp[i] - param$MNTTemp)
    # Also, calculate exchange
    # Multiple result below by -1 so that we have C_Cs (which is the inverse of what we do in the night time model)
    CalcTable$exchange[i]<- -1 * CalcTable$Cs_C[i] * CalcTable$K_adjusted[i]
  }

  # Reading the parameters table
  parameters = read.table(file=depth_fn, header=TRUE, sep="")

  # Calculate time
  my_last_time = paste(param$day, "23:59:59")
  my_last_ts = as.numeric(unclass(as.POSIXct(strptime(my_last_time, "%Y-%m-%d %H:%M:%S", tz="PST8PDT"))))
  my_first_ts = my_last_ts - 86400 - 3599 # back to the previous day, at 23:00

  # Subset data to only previous day@23hrs until the end of the current day
  SecondTable = subset(subset(CalcTable, DTseconds >= my_first_ts), DTseconds <= my_last_ts)

  # Convert sunrise, sunset
  sunrise = as.numeric(sunrise)
  sunset = as.numeric(sunset)

  ThirdTable = list()
  for (i in 1 : (length(SecondTable$DO) - 1)){
    aa = c(SecondTable$DTseconds[i], SecondTable$DTseconds[i+1])
      ThirdTable$DTseconds[i] = mean(aa)  
    bb = c(SecondTable$DO[i], SecondTable$DO[i+1])
      ThirdTable$AvgLDO[i] = mean(bb)
    cc = c(SecondTable$Temp[i], SecondTable$Temp[i+1])
      ThirdTable$AvgTemp[i] = mean(cc)    
    dd = c(SecondTable$exchange[i], SecondTable$exchange[i+1])
       ThirdTable$AvgExchange[i] = mean(dd)  # (gr / m3 h)
    # DO rate of change (mg/L = g/m3)
    ThirdTable$DOrateChangeVol[i] = (SecondTable$DO[i+1] - SecondTable$DO[i]) #(g / m3 h)
    # reaeration corrected rate of change per volume
    ThirdTable$ReaerCorrRateChangeVol[i] = ThirdTable$AvgExchange[i] + ThirdTable$DOrateChangeVol[i] # (gr / m3 h)
    # finally       
    ThirdTable$ReaerCorrRateChangeArea[i] = ThirdTable$ReaerCorrRateChangeVol[i] * parameters$depth # (gr / m2 h)
  }

  # Not used right now
  #  param$Velocity<- parameters$vel[param.day]   # velocity in m/s
  #  param$slope<- parameters$slope[param.day]    # bed slope in m/m

  # TO CALCULATE PRIMARY PRODUCTIVITY AND COMMUNITY RESPIRATION
  # For the metabolism calculation only Time stamp and reaeration corrected rate of change are necessary  
    
  # Obtaining the indices of daylight hours for the day of analysis
  daylight = which(ThirdTable$DTseconds >= sunrise & ThirdTable$DTseconds <= sunset)
  
  ids.sunrise = min(daylight)
  ids.sunset = max(daylight) 
    
  # subset of the day-time reaeration-corrected rate of change
  ThirdTable$ReaerationCorrRateChange_day[1 : (length(daylight))] = ThirdTable$ReaerCorrRateChangeArea[ids.sunrise : ids.sunset]

  # THE RESULTS I AM LOOKING FOR:

  # sum of the photoperiod rates of DO change (gr /m2 Ts)    
  ThirdTable$sum.corrDO.day = sum(ThirdTable$ReaerationCorrRateChange_day)    
  # cat("The sum of the photoperiod rates of DO change is:", ThirdTable$sum.corrDO.day, "(gr / m-2 h-1)")

  # Respiration Data
  # The total CR24 is the sum of the rates throughout the day for the temp corrected values of R
  ThirdTable$CR24 = sum(SecondTable$CR_adjusted) # using the R from the night Time method  
  # cat("The CR24 rate is:", ThirdTable$CR24, "(gr / m2 day)")
  
  # Calculation of the photoperiod respiration rate 
  dayligh = which(SecondTable$DTseconds >= sunrise & SecondTable$DTseconds <= sunset)
  ids.rise = min(daylight)
  ids.set = max(daylight) 
  ee = c()
  ee = SecondTable$CR_adjusted[ids.rise:ids.set]
  ThirdTable$photo.resp = sum(ee)
  # cat("The total respiration rate during photoperiod hours is:", ThirdTable$photo.resp, "(gr / m2-day)")  
     
  # Calculation of Gross Primary Productivity in g / m2-day
  ThirdTable$GPP = sum(ThirdTable$sum.corrDO.day + abs(ThirdTable$photo.resp))
  # cat("The Gross Primary Productivity for the selected day is:", ThirdTable$GPP, "(gr / m2-day)")

  # Calculation of Net Daily Metabolism in g / m2-day
  ThirdTable$NDM = ThirdTable$GPP + ThirdTable$CR24
  # cat("The Net Daily Metabolism for the selected day is:", ThirdTable$NDM, "(gr / m2-day)")
    
  # Calculation of the P/R ratio
  ThirdTable$P.R = ThirdTable$GPP / abs(ThirdTable$CR24) 
  # cat("The P/R ratio is:", ThirdTable$P.R)

# Storing Results in a data frame
  Results = list()
  Results$sum.corrDO.day = ThirdTable$sum.corrDO.day
  Results$CR24 = ThirdTable$CR24
  Results$photo.resp = ThirdTable$photo.resp
  Results$GPP = ThirdTable$GPP
  Results$NDM = ThirdTable$NDM
  Results$P.R = ThirdTable$P.R

  # Write metabolism model output
  write("Date\tsum.corrDO.day\tCR24\tphoto.rest\tGPP\tNDM\tP.R", file=output_fn)
  write(paste(param$day, "\t", Results$sum.corrDO.day, "\t", Results$CR24, "\t", Results$photo.resp, "\t", Results$GPP, "\t", Results$NDM, "\t", Results$P.R, sep=""), file=output_fn, append=TRUE)
