#!/usr/bin/env python

#############################################################
#
# Simple script to convert Hydrolab data file to a standard,
# tab-delimited file format
#
#############################################################

import os
import re
import sys

# Save our own basename
prog_base = os.path.split(sys.argv[0])[1]

if len(sys.argv) != 3:
    print "usage: %s input_file output_file" % (prog_base)
    exit(1)

# Get filenames
input_fn = sys.argv[1]
output_fn = sys.argv[2]

try:
    # Open input file
    f = open(input_fn)
except:
    print "error: could not open input file %s" % (input_fn)
    exit(1)

try:
    # Open output file
    o = open(output_fn, "w")
except:
    print "error: could not open output file %s" % (output_fn)
    exit(1)

# Find header
while True:
    line = f.readline()
    # End of file?
    if len(line) == 0:
        found = False
        break
    line = line.strip()
    if line.find("Date") > 0:
        # Found header line
        found = True
        break

if not found:
    print "error: not able to find header... exiting..."
    exit(1)

delim = re.compile("\s*,\s*");

# Get rid of extra quotes
line = line.replace('"', '')
# Rename Date/Time to DateTime
line = line.replace("Date/Time", "DateTime")
line = delim.split(line)
header = '\t'.join(line) + '\n'

o.write(header)

# Now process the rest of the file
for line in f:
    line = line.strip()
    try:
        temp = int(line[0])
    except:
        # Not a data line, skip it
        continue
    # Get rid of extra quotes
    line = line.replace('"', '')
    line = delim.split(line)
    data = '\t'.join(line) + '\n'
    o.write(data)

# Close file
f.close()
o.close()
