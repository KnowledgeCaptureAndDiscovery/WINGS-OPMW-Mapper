####### Script to Format Data and Time of CDEC data
# Date: Jun'2011
# Author: FS
# Input: Tab-delimited CDEC file with separate Date and Time columns
# Output: Tab-delimited data file with combined Date and Time columns
######################################

input_fn = ""
output_fn = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
#    cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if input_fn and output_fn are specified
if (input_fn == "" || output_fn == ""){
   cat("error: must specify input and output files and column names\n")
   quit()
}

# Check if input_fn exists
if (file.exists(input_fn) == FALSE){
   cat("error: cannot access input file\n")
   quit()
}

# Reading the CDEC data file 
  MainTable = read.table(file=input_fn, header=TRUE, sep="\t", check.names=FALSE)

  if ("Date" %in% colnames(MainTable) == FALSE){
     cat ("error: intput file missing Date field\n")
     quit()
  }

  if ("Time" %in% colnames(MainTable) == FALSE){
     cat ("error: intput file missing Time field\n")
     quit()
  }

  WorkTable = subset(MainTable, select=-c(Date, Time))

  for (i in 1:length(WorkTable[,1])){
      my_date = MainTable$Date[i]
      my_time = MainTable$Time[i]
      my_hour = as.numeric(substr(my_time, 1, 2))
      my_min = substr(my_time, 3, 5)
      if (my_hour > 11){
         my_ampm = "PM"
      } else {
         my_ampm = "AM"
      }

      # Adjust 13...23hrs to 1..11hrs
      if (my_hour > 12){
         my_hour = my_hour - 12
      }

      # Adjust 00AM to 12AM
      if (my_hour == 0){
         my_hour = 12
      }

      my_hour = paste(as.character(my_hour), my_min, ":00 ", my_ampm, sep="")
      MainTable$DateTime[i] = paste(my_date, " ", my_hour, sep="")
  }

  WorkTable = cbind(subset(MainTable, select=c(DateTime)), WorkTable)

  # Write output
  write.table(WorkTable, file = output_fn, append = FALSE, quote = FALSE, sep = "\t",
              na = "NA", dec = ".", row.names = FALSE, col.names = TRUE)
