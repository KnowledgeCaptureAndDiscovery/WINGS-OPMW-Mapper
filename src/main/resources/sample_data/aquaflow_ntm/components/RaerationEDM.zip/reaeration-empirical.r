####### Script to obtain metabolism estimates ######
# Date: May 04/2011
# Author: SV
# Input: Parameters.txt
# Output: hourly rates of K2(20C) from empirical methods
# Comment: 
######################################

input_fn = ""
output_fn = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
    #cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if input_fn and output_fn are specified
if (input_fn == "" || output_fn == ""){
   cat("error: must specify input and output files\n")
   quit()
}

# Check if input_fn exists
if (file.exists(input_fn) == FALSE){
   cat("error: cannot access input file\n")
   quit()
}

# Reading the parameters table
  parameters<- read.table(file=input_fn, header=TRUE, sep="")
  
# Converting Q(cfs) to Q (m3/s)  
  parameters$Q_cms<- parameters$Q_cfs * 0.02832

###############################################################################
# ENERGY DISSIPATION MODEL - EDM #
###############################################################################

  # Function to calculate Kprime
  Kprime_fun<- function(flow){
     # looking for the right K' parameter to use according to flow
     if (flow >= 0.028 && flow < 0.28) {
        Kprime<- 28300
     } else { 
        if (flow > 0.28 && flow <= 0.56) {
           Kprime<- 21300
        } else {
           Kprime<- 15300
        }
     }
     Kprime
  }
  
  # add new column with Kprime
  parameters$Kprime<- Kprime_fun(parameters$Q_cms)
  
  # calculating K2 (we want hourly rates so divide by 24)
  # K2(at temperature of 20 Celcius in units of h^-1)
  parameters$K2_edm<- (parameters$vel * parameters$slope * parameters$Kprime) / 24
  
  #NOTE I added two extra rows to the parameters file to test Kprime_fun

###############################################################################
# OWENS-GIBBS MODEL - OGM #
# O'CONNOR-DOBBINS MODEL - ODM #
# CHURCHILL ET AL MODEL - CM #
###############################################################################

# Function to determine the right method to use
  OtherMethods_fun<- function(depth, velocity){
    # looking for the right K' parameter to use according to flow
    if (depth <= 0.61) {
      K2_OtherMethods<- ((5.32 * (velocity^0.67) * (depth^(-1.85))) / 24 )
    } else { 
      if (depth > 0.61 && depth > (3.45 * velocity^2.5) ) {
         K2_OtherMethods<- ((3.93 * (velocity^0.5) * (depth^(-1.5))) / 24 )
      } 
      else {
         K2_OtherMethods<- ((5.026 * (velocity) * (depth^(-1.67))) / 24 )
      }
    }
    K2_OtherMethods
  }

  # a new column with K2 calculated from either OGM, ODM, or CM 
  parameters$K2_OtherMethods<- OtherMethods_fun(parameters$depth, parameters$vel)

  write.table(parameters, file = output_fn, append = FALSE, quote = FALSE, sep = "\t",
              na = "NA", dec = ".", row.names = FALSE, col.names = TRUE)
