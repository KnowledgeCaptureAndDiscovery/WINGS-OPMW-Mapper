####### Script to Calculate averages for the Hydrolab data
# Date: Mar'2011
# Author: SV and FS
# Input: Water quality data (at least temperature and dissolved oxygen): Hydrolab_Stationary.txt
# Output: Hourly averages
# Comment: For One-hour estimates
######################################

input_fn = ""
output_fn = ""

# Now, get all command-line assignments
for (e in commandArgs()) {
  ta = strsplit(e,"=",fixed=TRUE)
  if(! is.na(ta[[1]][2])) {
    temp = ta[[1]][2]
    assign(ta[[1]][1],temp)
#    cat("assigned ",ta[[1]][1]," the value of |",temp,"|\n")
  }
}

# Check if input_fn and output_fn are specified
if (input_fn == "" || output_fn == ""){
   cat("error: must specify input and output files\n")
   quit()
}

# Check if input_fn exists
if (file.exists(input_fn) == FALSE){
   cat("error: cannot access input file\n")
   quit()
}

# Reading the water quality data file 
  MainTable = read.table(file=input_fn, header=TRUE, sep="\t")
  dates = strptime(MainTable$DateAndTime, "%Y-%m-%d", tz="PST8PDT")
  AA = MainTable
  AA$MyDate = strptime(MainTable$DateAndTime, "%Y-%m-%d", tz="PST8PDT")
  ud = unique(dates)

  OutputTable = data.frame()

  for (i in 1:length(ud)){
      BB = subset(AA, AA$MyDate == ud[i])
      # check that you are getting the right positions for hours
      BB$hour = as.numeric(substr(BB$DateAndTime, 12, 13))
      hours = c(0:23)
      Table = list()
      for (j in 1:24){
      	  CC = subset(BB, BB$hour == hours[j]) 
    	  Table$DTseconds[j]<- mean(CC$DTseconds)  
    	  Table$Temp[j]<- mean(as.numeric(as.vector(CC$Temp)))
    	  Table$DO[j]<- mean(as.numeric(as.vector(CC$DO)))
      }
      Table1 = as.data.frame(Table)
      DD = subset(Table1, Table$DTseconds > 0)
      OutputTable = rbind(OutputTable, DD)
  }

  # Writing a table of the hourly averages for the available data
  write.table(OutputTable, file = output_fn, append = FALSE, quote = FALSE, sep = "\t",
            na = "NA", dec = ".", row.names = FALSE, col.names = TRUE )
